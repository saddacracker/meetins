exports.handler = async () => {
    return [
        {
            "id": "1abc",
            "name": "A Vision For You",
            "day": 4
        },
        {
            "id": "2def",
            "name": "New Life",
            "day": 1
        }
    ];
};
