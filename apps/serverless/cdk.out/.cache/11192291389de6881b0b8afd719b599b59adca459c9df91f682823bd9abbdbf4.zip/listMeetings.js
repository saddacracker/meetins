const handler = async () => {
 return [
     {
        id: '1-abc',
        name: "A Vision For You",
        day: 4
     },
     {
        id: '2-abc',
        name: "Bridge To Faith",
        day: 1
     }
 ];
};

export default handler;